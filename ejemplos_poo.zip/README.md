# Ejemplos de Programación Orientada a Objetos (POO)

Este repositorio contiene varios ejemplos creados a partir de la guía del profesor.

## Contenido
- **ejemplo_clases_basicas.py** → Introducción a clases y objetos  
- **ejemplo_herencia.py** → Ejemplo simple de herencia  
- **ejemplo_polimorfismo.py** → Ejemplo de polimorfismo  
- **mini_juego_poo/** → Mini juego hecho por mí basado en POO  
