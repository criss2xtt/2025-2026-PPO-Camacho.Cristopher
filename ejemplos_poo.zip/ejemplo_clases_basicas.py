class Animal:
    def __init__(self, nombre):
        self.nombre = nombre

    def hablar(self):
        return "Sonido genérico"

a = Animal("Criatura")
print(a.nombre, a.hablar())