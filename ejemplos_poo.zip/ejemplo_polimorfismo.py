class Ave:
    def sonido(self):
        return "Sonido de ave"

class Loro(Ave):
    def sonido(self):
        return "Hola! soy un loro"

class Aguila(Ave):
    def sonido(self):
        return "Grrrr!"

aves=[Loro(), Aguila()]
for ave in aves:
    print(ave.sonido())