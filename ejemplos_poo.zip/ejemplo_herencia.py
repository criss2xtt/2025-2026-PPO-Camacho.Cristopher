class Vehiculo:
    def __init__(self, marca):
        self.marca = marca

class Auto(Vehiculo):
    def __init__(self, marca, modelo):
        super().__init__(marca)
        self.modelo = modelo

a = Auto("Toyota", "Corolla")
print("Marca:", a.marca, "- Modelo:", a.modelo)