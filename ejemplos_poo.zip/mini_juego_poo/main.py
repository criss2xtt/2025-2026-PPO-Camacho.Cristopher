from personaje import Personaje
from guerrero import Guerrero
from combate import combate

def main():
    p1 = Guerrero("Ragnar", 10, 5)
    p2 = Personaje("Goblin", 8)

    combate(p1, p2)

if __name__ == "__main__":
    main()