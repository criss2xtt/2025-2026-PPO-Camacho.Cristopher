from personaje import Personaje

class Guerrero(Personaje):
    def __init__(self, nombre, poder, espada):
        super().__init__(nombre, poder)
        self.espada = espada

    def atacar(self, enemigo):
        daño = self.poder + self.espada
        enemigo.vida -= daño
        print(f"{self.nombre} golpeó con espada y causó {daño} de daño.")
