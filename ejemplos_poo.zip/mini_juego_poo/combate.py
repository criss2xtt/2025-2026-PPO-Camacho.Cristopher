def combate(a, b):
    print("Inicia el combate!")
    while a.vida > 0 and b.vida > 0:
        a.atacar(b)
        if b.vida <= 0: break
        b.atacar(a)

    ganador = a if a.vida > 0 else b
    print("Ganador:", ganador.nombre)
