class Personaje:
    def __init__(self, nombre, poder):
        self.nombre = nombre
        self.poder = poder
        self.vida = 100

    def atacar(self, enemigo):
        enemigo.vida -= self.poder
        print(f"{self.nombre} atacó a {enemigo.nombre} y causó {self.poder} de daño.")
